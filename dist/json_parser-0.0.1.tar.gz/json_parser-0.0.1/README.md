# `json_parser`

json_parser is a package to dynamically search through a json object by key.
